===============
``mptt.models``
===============

.. automodule:: mptt.models
    :members:
    :undoc-members:
